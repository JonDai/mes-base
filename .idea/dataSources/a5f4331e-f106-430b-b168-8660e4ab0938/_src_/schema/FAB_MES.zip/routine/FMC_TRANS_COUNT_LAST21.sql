create PROCEDURE FMC_TRANS_COUNT_LAST21 IS

BEGIN
  UPDATE FMC_SUMMARY_INFO
     SET TRANS_COUNT_LAST21 =
         (
SELECT COUNT(*) AS QTY
  FROM MCS_TRANSFERJOB_HIS@TO_MCS
 WHERE EVENTTIME >=
                 TO_TIMESTAMP(TO_CHAR(CASE
                                          WHEN to_char(SYSDATE, 'hh24') >= 21 THEN
                                           SYSDATE
                                          ELSE
                                           SYSDATE - 1
                                        END, 'yyyy/mm/dd ') ||
                              '21:00:00.000',
                              'yyyy/mm/dd hh24:mi:ss.ff3'));
  COMMIT;
END;

 
 
 
 
 
 