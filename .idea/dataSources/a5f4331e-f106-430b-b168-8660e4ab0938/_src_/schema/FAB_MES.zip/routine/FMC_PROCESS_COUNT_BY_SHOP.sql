create procedure FMC_PROCESS_COUNT_BY_SHOP is

begin
  UPDATE FMC_SUMMARY_INFO
     SET PROCESS_COUNT_BY_SHOP =
         (SELECT COUNT(*) AS QTY
            FROM WIP_LOT T
           WHERE T.MAIN_MAT_TYPE IN ('Panel','Glass')
             AND T.EQUIPMENT_ID IS NOT NULL
             AND T.COM_CLASS = 'WIP');
  commit;
end;

 
 
 
 
 
 