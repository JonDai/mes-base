create PROCEDURE FMC_PROCESS_COUNT_TODAY IS

BEGIN
  UPDATE FMC_SUMMARY_INFO
     SET PROCESS_COUNT_TODAY =
         (SELECT COUNT(*) AS QTY
            FROM WIP_LOT_HIS T
           WHERE T.MAIN_MAT_TYPE = 'Glass'
                 AND T.TRANS_TYPE='TRACKOUT'
                 AND T.TRANS_TIME >=
                 TO_TIMESTAMP(TO_CHAR(SYSDATE, 'yyyy/mm/dd ') ||
                              '00:00:00.000',
                              'yyyy/mm/dd hh24:mi:ss.ff3'));
  COMMIT;
END;

 
 
 
 
 
 