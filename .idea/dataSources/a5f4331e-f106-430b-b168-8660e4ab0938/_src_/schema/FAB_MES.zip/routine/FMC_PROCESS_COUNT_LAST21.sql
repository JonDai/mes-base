create PROCEDURE FMC_PROCESS_COUNT_LAST21 IS

BEGIN
  UPDATE FMC_SUMMARY_INFO
     SET PROCESS_COUNT_LAST21 =
         (SELECT COUNT(*) AS QTY
            FROM WIP_LOT_HIS T
           WHERE T.MAIN_MAT_TYPE ='Glass'
                 AND T.TRANS_TYPE='TRACKOUT'
                 AND T.TRANS_TIME >=
                 TO_TIMESTAMP(TO_CHAR(CASE
                                          WHEN to_char(SYSDATE, 'hh24') >= 21 THEN
                                           SYSDATE
                                          ELSE
                                           SYSDATE - 1
                                        END, 'yyyy/mm/dd ') ||
                              '21:00:00.000',
                              'yyyy/mm/dd hh24:mi:ss.ff3'));
  COMMIT;
END;

 
 
 
 
 
 