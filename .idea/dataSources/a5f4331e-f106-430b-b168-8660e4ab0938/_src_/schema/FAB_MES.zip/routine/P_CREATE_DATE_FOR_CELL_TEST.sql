create PROCEDURE P_CREATE_DATE_FOR_CELL_TEST(makeNum IN NUMBER,
                            componnentNum IN NUMBER, cellNum IN NUMBER,
                            durableId IN VARCHAR2, workOrderId IN VARCHAR2,
                            lotId IN VARCHAR2, cellId IN VARCHAR2) AS
    i NUMBER := 0;
    x NUMBER := 0;
    y NUMBER := 0;
    lotRrn NUMBER;
    subLotRrn NUMBER;
    componentRrn NUMBER;
    componentSeq VARCHAR2(10);
    cursor workOrder is select doc_id,owner from wip_wo where doc_id = workOrderId;
    c_wo workOrder%rowtype;
BEGIN
    while i < makeNum LOOP
        BEGIN
            open workOrder;
            fetch workOrder into c_wo;
            --更新CST状态
            UPDATE mm_carrier set com_class = 'ACT',state = 'ACT',current_qty = componnentNum where durable_id = durableId;
            lotRrn := HIBERNATE_SEQUENCE.NEXTVAL;
            -- 创建主LOT
            INSERT INTO wip_lot (OBJECT_RRN, ORG_RRN, IS_ACTIVE, LOCK_VERSION, DURABLE, PART_RRN, PART_NAME,PROCESS_RRN,Process_Name,Procedure_Rrn,PROCEDURE_NAME, STEP_RRN,STEP_NAME, UPDATED, LOT_TYPE, MAIN_QTY, IS_SUB_LOT, COM_CLASS, STATE, LOT_ID, MANUFA            select lotRrn, 10, 'Y', 1, durableId , 95863684, 'D2AB', 95863662, 'D2AB',95863624,'D2AB',95768723,'100001', sysdate, '1000', componnentNum, 'N', 'CMP','CMP', lotId, 'MP', c_wo.doc_id, c_wo.owner,'N','N','N' from dual;
            -- 创建SUBLOT以及COMPONENT
            x := x + 1;
            while x <=  componnentNum LOOP
                BEGIN
                  IF x < 10 THEN componentSeq := '0' || x;
                  ELSE componentSeq := x;
                  END IF;
                    subLotRrn := HIBERNATE_SEQUENCE.NEXTVAL;
                    INSERT INTO wip_lot (OBJECT_RRN, ORG_RRN, IS_ACTIVE, LOCK_VERSION, PARENT_UNIT_RRN,PART_RRN, PART_NAME,PROCESS_RRN,Process_Name,Procedure_Rrn,PROCEDURE_NAME, STEP_RRN,STEP_NAME, UPDATED, MAIN_QTY, IS_SUB_LOT, MASK, LOT_ID,COM_CLASS, STA                    select subLotRrn, 10, 'Y', 1, lotRrn, 95863684, 'D2AB', 95863662, 'D2AB',95863624,'D2AB',95768723,'100001', sysdate, 1, 'Y', 'MASK1', lotId || componentSeq, 'CMP','CMP', 'MP',c_wo.doc_id, c_wo.owner,'N','N' from dual;
                    -- 创建Component
                    componentRrn := HIBERNATE_SEQUENCE.NEXTVAL;
                    INSERT INTO wip_componentunit (OBJECT_RRN, ORG_RRN, IS_ACTIVE, LOCK_VERSION, PARENT_UNIT_RRN, COMPONENT_ID,PART_RRN, PART_NAME,PROCESS_RRN,Process_Name,Procedure_Rrn,PROCEDURE_NAME, STEP_RRN,STEP_NAME, UPDATED, COM_CLASS, STATE, DURABLE                    select componentRrn, 10, 'Y', 1, subLotRrn, lotId || componentSeq, 95863684, 'D2AB', 95863662, 'D2AB',95863624,'D2AB',95768723,'100001', sysdate, 'CMP', 'CMP', durableId, 'MP', '0', c_wo.doc_id,'N' from dual;
                    -- 创建ComponentCell
                    while y < cellNum LOOP
                        BEGIN
                            INSERT INTO WIP_COMPONENTUNIT_CELL(OBJECT_RRN, ORG_RRN, IS_ACTIVE, LOCK_VERSION, UPDATED, CELL_ID, JUDGE1, COMPONENT_RRN)
                            SELECT HIBERNATE_SEQUENCE.NEXTVAL, 10, 'Y', 1, sysdate, cellId || y, 'OK', componentRrn FROM dual;
                            y := y + 1;
                        END;
                    END LOOP;
                    y := 1;
                END;
                x := x + 1;
            END LOOP;
            x := 1;
            i := i + 1;
            close workOrder;
        END;

    END LOOP;
    commit;
END;
