create procedure FMC_TRANSFER_COUNT_24_SHOP  is
BEGIN
 EXECUTE IMMEDIATE 'TRUNCATE TABLE FMC_TRANSFER_COUNT_24 REUSE STORAGE';
INSERT INTO FMC_TRANSFER_COUNT_24
    (OBJECT_RRN,  HOUR, TRANSFER_COUNT)
    (SELECT 
           Hibernate_Sequence.Nextval,
           SUBSTR(Z.DATETIME,9,2) AS HOUR,
           Z.QTY
       FROM (SELECT TO_CHAR(T.EVENTTIME, 'yyyymmddhh24') AS DATETIME,
               COUNT(*) AS QTY
         FROM MCS_TRANSFERJOB_HIS@TO_MCS T
 WHERE EVENTTIME >=
               TO_TIMESTAMP(TO_CHAR(SYSDATE -1+ (1 / 24),
                                    'yyyy/mm/dd hh24') || ':00:00',
                            'yyyy/mm/dd hh24:mi:ss')
         GROUP BY TO_CHAR(T.EVENTTIME, 'yyyymmddhh24')
         ORDER BY TO_CHAR(T.EVENTTIME, 'yyyymmddhh24')) Z
      where rownum < 24);
    COMMIT;
END;

 
 
 
 
 
 