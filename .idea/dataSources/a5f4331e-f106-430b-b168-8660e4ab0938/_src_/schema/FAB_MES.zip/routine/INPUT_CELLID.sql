create PROCEDURE INPUT_CELLID (
                                    outErrCode  OUT VARCHAR2,
                                    outErrMsg  OUT VARCHAR2
                                    ) AS

BEGIN
     FOR i IN 1..10
     LOOP
     INSERT INTO BAS_CELL_NAMING_RULE VALUES (2000+i, 0, 'Y', 'SGLASSCHIPID', i, 1, i, 'A'|| i);
     END LOOP;

      FOR i IN 1..10
     LOOP
     INSERT INTO BAS_CELL_NAMING_RULE VALUES (2010+i, 0, 'Y', 'SGLASSCHIPID', 10+i, 2, i, 'B'|| i);
     END LOOP;

      FOR i IN 1..10
     LOOP
     INSERT INTO BAS_CELL_NAMING_RULE VALUES (2020+i, 0, 'Y', 'SGLASSCHIPID', 20+i, 3, i, 'C'|| i);
     END LOOP;

      FOR i IN 1..10
     LOOP
     INSERT INTO BAS_CELL_NAMING_RULE VALUES (2030+i, 0, 'Y', 'SGLASSCHIPID', 30+i, 4, i, 'D'|| i);
     END LOOP;

      FOR i IN 1..10
     LOOP
     INSERT INTO BAS_CELL_NAMING_RULE VALUES (2040+i, 0, 'Y', 'SGLASSCHIPID', 40+i, 5, i, 'E'|| i);
     END LOOP;

      FOR i IN 1..10
     LOOP
     INSERT INTO BAS_CELL_NAMING_RULE VALUES (2050+i, 0, 'Y', 'SGLASSCHIPID', 50+i, 6, i, 'F'|| i);
     END LOOP;

      FOR i IN 1..10
     LOOP
     INSERT INTO BAS_CELL_NAMING_RULE VALUES (2060+i, 0, 'Y', 'SGLASSCHIPID', 60+i, 7, i, 'G'|| i);
     END LOOP;

      FOR i IN 1..10
     LOOP
     INSERT INTO BAS_CELL_NAMING_RULE VALUES (2070+i, 0, 'Y', 'SGLASSCHIPID', 70+i, 8, i, 'H'|| i);
     END LOOP;

      FOR i IN 1..10
     LOOP
     INSERT INTO BAS_CELL_NAMING_RULE VALUES (2080+i, 0, 'Y', 'SGLASSCHIPID', 80+i, 9, i, 'I'|| i);
     END LOOP;

      FOR i IN 1..10
     LOOP
     INSERT INTO BAS_CELL_NAMING_RULE VALUES (2090+i, 0, 'Y', 'SGLASSCHIPID', 90+i, 10, i, 'J'|| i);
     END LOOP;

 COMMIT;
 EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;

END INPUT_CELLID;

 
 
 
 
 
 