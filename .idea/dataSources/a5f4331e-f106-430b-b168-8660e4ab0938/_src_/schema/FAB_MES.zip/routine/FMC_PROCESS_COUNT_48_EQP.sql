create PROCEDURE FMC_PROCESS_COUNT_48_EQP IS

BEGIN

  DELETE FROM FMC_PROCESS_48 WHERE ORG_RRN = 20 AND HOUR = TO_CHAR(SYSDATE - 2, 'DD hh24');
  INSERT INTO FMC_PROCESS_48
    (OBJECT_RRN, HOUR, PROCESS_COUNT, EQPT_ID)
    (SELECT Hibernate_Sequence.Nextval,
            SUBSTR(Z.DATETIME,9,5) AS HOURNUM,
            Z.COUNT,
            Z.EQUIPMENT_ID
       FROM (SELECT TO_CHAR(TRANS_TIME, 'yyyy/mm/dd hh24') AS DATETIME,
                    EQUIPMENT_ID,
                    SUM(MAIN_QTY) AS COUNT
               FROM WIP_LOT_HIS T
              WHERE T.TRANS_TYPE = 'TRACKOUT'
                AND T.MAIN_MAT_TYPE = 'Glass'
                AND T.TRANS_TIME >=
                    TO_TIMESTAMP(TO_CHAR(SYSDATE - (1 / 24)-2,
                                 'yyyy/mm/dd hh24')||':00:00',
                                 'yyyy/mm/dd hh24:mi:ss')
                AND T.TRANS_TIME <=
                    TO_TIMESTAMP(TO_CHAR(SYSDATE - (1 / 24),
                                 'yyyy/mm/dd hh24')||':59:59',
                                 'yyyy/mm/dd hh24:mi:ss')
              GROUP BY TO_CHAR(TRANS_TIME, 'yyyy/mm/dd hh24'),
                       EQUIPMENT_ID
              ORDER BY TO_CHAR(TRANS_TIME, 'yyyy/mm/dd hh24')) Z) ;

  COMMIT;
END;

 
 
 
 
 
 