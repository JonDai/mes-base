create PROCEDURE P_CREATE_DATE_FOR_SL(makeNum IN NUMBER,
                            componnentNum IN NUMBER, cellNum IN NUMBER,
                            durablePrefix IN VARCHAR2, componentPrefix IN VARCHAR2,
                            cellPrefix IN VARCHAR2) AS
    i NUMBER := 0;
    x NUMBER := 0;
    y NUMBER := 0;
    lotRrn NUMBER;
    subLotRrn NUMBER;
    componentRrn NUMBER;
BEGIN
    while i < makeNum LOOP
        BEGIN   
            lotRrn := HIBERNATE_SEQUENCE.NEXTVAL;
            -- 创建主LOT
            INSERT INTO wip_lot (OBJECT_RRN, ORG_RRN, IS_ACTIVE, LOCK_VERSION, DURABLE, PART_NAME, UPDATED, LOT_TYPE, MAIN_QTY, IS_SUB_LOT, STATE, LOT_ID)
            select lotRrn, 12, 'Y', 1, durablePrefix || i, 'part1', sysdate, '1', componnentNum, 'N', 'SHIPREQ', durablePrefix || i from dual; 
            -- 创建SUBLOT以及COMPONENT
            while x <  componnentNum LOOP
                BEGIN
                    subLotRrn := HIBERNATE_SEQUENCE.NEXTVAL;
                    INSERT INTO wip_lot (OBJECT_RRN, ORG_RRN, IS_ACTIVE, LOCK_VERSION, PARENT_UNIT_RRN, PART_NAME, MAIN_QTY, IS_SUB_LOT, MASK, LOT_ID)
                    select subLotRrn, 12, 'Y', 1, lotRrn, 'part1', 1, 'Y', 'MASK1', 'SUB' || durablePrefix || x  from dual; 
                    -- 创建Component
                    componentRrn := HIBERNATE_SEQUENCE.NEXTVAL;
                    INSERT INTO wip_componentunit (OBJECT_RRN, ORG_RRN, IS_ACTIVE, LOCK_VERSION, PARENT_UNIT_RRN, COMPONENT_ID)
                    select componentRrn, 12, 'Y', 1, subLotRrn, componentPrefix || x from dual; 
                    -- 创建ComponentCell
                    while y < cellNum LOOP
                        BEGIN
                            INSERT INTO WIP_COMPONENTUNIT_CELL(OBJECT_RRN, ORG_RRN, IS_ACTIVE, LOCK_VERSION, CELL_ID, JUDGE1, COMPONENT_RRN)
                            SELECT HIBERNATE_SEQUENCE.NEXTVAL, 12, 'Y', 1, cellPrefix || y, 'OK', componentRrn FROM dual;  
                            y := y + 1;
                        END;
                    END LOOP;
                    y := 0;
                    
                    x := x + 1;
                END;
            END LOOP;
            x := 0;
            i := i + 1;
        END;

    END LOOP;
    commit;
END;
 
 