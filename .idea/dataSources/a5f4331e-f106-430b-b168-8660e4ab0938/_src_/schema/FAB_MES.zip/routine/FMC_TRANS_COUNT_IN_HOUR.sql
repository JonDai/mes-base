create PROCEDURE FMC_TRANS_COUNT_IN_HOUR IS

BEGIN
  UPDATE FMC_SUMMARY_INFO
     SET TRANS_COUNT_IN_HOUR =
         (
SELECT COUNT(*) AS QTY
  FROM MCS_TRANSFERJOB_HIS@TO_MCS
 WHERE EVENTTIME >=
                 TO_TIMESTAMP(TO_CHAR(SYSDATE, 'yyyy/mm/dd hh24') ||
                              ':00:00.000',
                              'yyyy/mm/dd hh24:mi:ss.ff3')
             AND TO_TIMESTAMP(EVENTTIME, 'yyyymmddhh24missff') <=
                 TO_TIMESTAMP(TO_CHAR(SYSDATE, 'yyyy/mm/dd hh24') ||
                              ':59:59.999',
                              'yyyy/mm/dd hh24:mi:ss.ff3'));
  COMMIT;
END;

 
 
 
 
 
 