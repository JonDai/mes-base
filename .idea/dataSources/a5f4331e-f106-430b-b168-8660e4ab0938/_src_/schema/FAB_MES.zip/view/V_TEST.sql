create view V_TEST as
select k."LEVEL",k."LOT_RRN",k."LOT_ID",k."PROCESS_INSTANCE_RRN",k."NODE_RRN",k."SUPER_RRN",k."SUPER_START_NODE_RRN", n.process_definition_rrn, n.class state_class, n.name state_name, n.sub_process_name, w.name process_name
from
(select level, t.*, k.node_rrn, k.super_rrn, k.super_start_node_rrn from
(select lot_rrn, lot_id, t.process_instance_rrn from
(select t.object_rrn lot_rrn, t.lot_id, t.process_instance_rrn from wip_lot t
 where t.com_class = 'WIP'
 and t.process_instance_rrn is not null
 --and t.rework_stack_count != 0
) t, wf_processinstance i
where t.process_instance_rrn = i.object_rrn) t, wf_token k, wf_processinstance i
where i.instance_key = t.lot_rrn
  and i.root_token_rrn = k.object_rrn
start with i.object_rrn = t.process_instance_rrn
 connect by i.object_rrn = prior k.sub_process_instance_rrn) k, wf_node n, wf_processdefinition w
 where
 k.node_rrn = n.object_rrn
 and n.process_definition_rrn = w.object_rrn

 
 
