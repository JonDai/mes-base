package com.ccpd.log.model;

/**
 * Created by jondai on 2017/11/7.
 */
public interface Constants {
    String MES_XML = "/Users/jondai/code/panda/mes-base/mes-mcs-log/src/test/java/com/ccpd/service/mes.xml";
    String MCS_XML = "/Users/jondai/code/panda/mes-base/mes-mcs-log/src/test/java/com/ccpd/service/mcs.xml";
    String MES_MCS = "/Users/jondai/code/panda/mes-base/mes-mcs-log/src/main/resources/log/MES-MCS.log";
    String MCS_MES = "/Users/jondai/code/panda/mes-base/mes-mcs-log/src/main/resources/log/MCS-MES.log";

    String SHOP_NAME_GLOBAL = "0";
    String SHOP_NAME_Array = "10";
    String SHOP_NAME_CF = "11";
    String SHOP_NAME_CELL = "12";
    String SHOP_NAME_SL = "13";
    String SHOP_NAME_OC = "14";




}
