package com.ccpd.service;

import com.ccpd.log.dao.RequestMessageDao;
import com.ccpd.log.model.Constants;
import com.ccpd.log.model.RequestMessage;
import com.ccpd.log.service.FileService;
import com.ccpd.log.service.LoggerService;
import com.ccpd.log.service.StringParseService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Created by jondai on 2017/11/8.
 */

@RunWith(SpringRunner.class)
@SpringBootTest
public class LoggerTester {
    @Autowired
    private LoggerService loggerService;

    @Autowired
    private StringParseService stringParseService;

    @Autowired
    private volatile RequestMessageDao requestMessageDao;

    @Test
    public void convertToRequestMessage() throws Exception {

        loggerService.convertToRequestMessage();
    }


    @Test
    public void saveRequestMessageByXML() throws Exception {
        loggerService.saveRequestMessageByXML();
    }

    @Test
    public void saveResponseMessageByXML() throws Exception {
        loggerService.saveResponseMessageByXML();
    }

    @Test
    public void simulateMessageTest() throws Exception {
        loggerService.simulateMessageTest();
    }

    @Test
    public void testThread() throws Exception {
        new Thread(() -> {

            System.out.println("hello >>>>>>>>>>>>>>>>>>>>>>>>>>>");
            System.out.println(Thread.currentThread().getName());
//            loggerService.test();
            RequestMessage one = this.requestMessageDao.findOne("201711081031058003");
            System.out.println(one.toString());

        }).start();
    }
}
